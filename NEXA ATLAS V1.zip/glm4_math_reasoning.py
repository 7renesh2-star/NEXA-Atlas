#!/usr/bin/env python3
"""
GLM-4-Math Architecture
- Mathematical reasoning capabilities
- Scientific computation pipeline
- Chain-of-thought mathematics
- Symbolic reasoning
- Formula recognition and processing
- Verification and validation
"""

import re
import math
import logging
from typing import List, Dict, Tuple, Optional, Any
from dataclasses import dataclass, field
from enum import Enum
import numpy as np

logger = logging.getLogger(__name__)


class ReasoningType(Enum):
    """Types of reasoning in GLM-4-Math"""
    ALGEBRAIC = "algebraic"
    GEOMETRIC = "geometric"
    CALCULUS = "calculus"
    LOGIC = "logic"
    STATISTICAL = "statistical"
    COMPUTATIONAL = "computational"


@dataclass
class MathStep:
    """Single step in mathematical reasoning"""
    step_number: int
    reasoning_type: ReasoningType
    description: str
    formula: Optional[str] = None
    result: Optional[str] = None
    confidence: float = 0.9
    explanation: str = ""


@dataclass
class MathProblem:
    """Mathematical problem with solution"""
    problem_statement: str
    problem_type: ReasoningType
    steps: List[MathStep] = field(default_factory=list)
    final_answer: Optional[str] = None
    verification_passed: bool = False
    difficulty_score: float = 0.0


class MathExpressionParser:
    """Parse and analyze mathematical expressions"""
    
    # Mathematical function patterns
    MATH_FUNCTIONS = {
        'sin': lambda x: math.sin(x),
        'cos': lambda x: math.cos(x),
        'tan': lambda x: math.tan(x),
        'sqrt': lambda x: math.sqrt(x),
        'exp': lambda x: math.exp(x),
        'log': lambda x: math.log(x),
        'ln': lambda x: math.log(x),
        'abs': lambda x: abs(x),
        'log10': lambda x: math.log10(x),
    }
    
    # Operator precedence
    OPERATOR_PRECEDENCE = {
        '+': 1,
        '-': 1,
        '*': 2,
        '/': 2,
        '%': 2,
        '**': 3,
        '^': 3,
    }
    
    def __init__(self):
        self.expression_pattern = re.compile(
            r'([0-9.]+|[a-zA-Z_][a-zA-Z0-9_]*|\+|-|\*|/|%|\(|\)|=)'
        )
    
    def tokenize(self, expression: str) -> List[str]:
        """Tokenize mathematical expression"""
        return self.expression_pattern.findall(expression.replace(' ', ''))
    
    def identify_operations(self, expression: str) -> List[Tuple[str, int]]:
        """Identify operations and precedence"""
        tokens = self.tokenize(expression)
        operations = []
        
        for i, token in enumerate(tokens):
            if token in self.OPERATOR_PRECEDENCE:
                precedence = self.OPERATOR_PRECEDENCE[token]
                operations.append((token, precedence))
        
        return operations
    
    def identify_functions(self, expression: str) -> List[str]:
        """Identify mathematical functions in expression"""
        functions = []
        
        for func in self.MATH_FUNCTIONS.keys():
            pattern = rf'{func}\s*\('
            if re.search(pattern, expression):
                functions.append(func)
        
        return functions
    
    def identify_problem_type(self, expression: str) -> ReasoningType:
        """Identify type of mathematical problem"""
        
        expression_lower = expression.lower()
        
        # Algebraic
        if any(x in expression_lower for x in ['solve', 'equation', '=', 'x', 'y', 'z']):
            return ReasoningType.ALGEBRAIC
        
        # Geometric
        if any(x in expression_lower for x in ['angle', 'distance', 'area', 'volume', 'circle', 'triangle', 'sphere']):
            return ReasoningType.GEOMETRIC
        
        # Calculus
        if any(x in expression_lower for x in ['derivative', 'integral', 'limit', 'differential', 'd/dx']):
            return ReasoningType.CALCULUS
        
        # Statistical
        if any(x in expression_lower for x in ['probability', 'mean', 'median', 'variance', 'distribution', 'sample']):
            return ReasoningType.STATISTICAL
        
        # Logic
        if any(x in expression_lower for x in ['and', 'or', 'not', 'if', 'then', 'prove']):
            return ReasoningType.LOGIC
        
        # Default to computational
        return ReasoningType.COMPUTATIONAL


class GLM4MathReasoner:
    """GLM-4-Math reasoning engine"""
    
    def __init__(self):
        self.parser = MathExpressionParser()
        self.reasoning_history: List[MathProblem] = []
        self.verified_results: Dict[str, Any] = {}
    
    def parse_problem(self, problem_statement: str) -> MathProblem:
        """Parse and categorize mathematical problem"""
        
        problem_type = self.parser.identify_problem_type(problem_statement)
        
        problem = MathProblem(
            problem_statement=problem_statement,
            problem_type=problem_type,
            difficulty_score=self._estimate_difficulty(problem_statement)
        )
        
        logger.info(f"Parsed problem: type={problem_type.value}, "
                   f"difficulty={problem.difficulty_score:.2f}")
        
        return problem
    
    def _estimate_difficulty(self, problem_statement: str) -> float:
        """Estimate problem difficulty (0-1)"""
        
        difficulty = 0.5
        
        # Increase for complex terms
        complex_terms = ['integral', 'derivative', 'eigenvalue', 'tensor', 'manifold', 'topology']
        difficulty += 0.05 * sum(1 for term in complex_terms if term in problem_statement.lower())
        
        # Increase for multiple operations
        operations = self.parser.identify_operations(problem_statement)
        difficulty += 0.05 * len(operations)
        
        # Increase for functions
        functions = self.parser.identify_functions(problem_statement)
        difficulty += 0.05 * len(functions)
        
        return min(1.0, difficulty)
    
    def generate_reasoning_steps(self, problem: MathProblem) -> None:
        """Generate step-by-step reasoning for problem"""
        
        logger.info(f"Generating reasoning steps for {problem.problem_type.value} problem")
        
        if problem.problem_type == ReasoningType.ALGEBRAIC:
            self._algebraic_reasoning(problem)
        elif problem.problem_type == ReasoningType.GEOMETRIC:
            self._geometric_reasoning(problem)
        elif problem.problem_type == ReasoningType.CALCULUS:
            self._calculus_reasoning(problem)
        elif problem.problem_type == ReasoningType.STATISTICAL:
            self._statistical_reasoning(problem)
        elif problem.problem_type == ReasoningType.LOGIC:
            self._logic_reasoning(problem)
        else:
            self._computational_reasoning(problem)
    
    def _algebraic_reasoning(self, problem: MathProblem) -> None:
        """Algebraic problem solving"""
        
        steps = [
            MathStep(
                step_number=1,
                reasoning_type=ReasoningType.ALGEBRAIC,
                description="Identify variables and constants",
                explanation="First, we identify all variables and constants in the equation"
            ),
            MathStep(
                step_number=2,
                reasoning_type=ReasoningType.ALGEBRAIC,
                description="Simplify both sides",
                explanation="Apply algebraic operations to simplify",
                formula="Combine like terms"
            ),
            MathStep(
                step_number=3,
                reasoning_type=ReasoningType.ALGEBRAIC,
                description="Isolate variable",
                explanation="Move all terms with the variable to one side",
                formula="ax + b = 0 → x = -b/a"
            ),
            MathStep(
                step_number=4,
                reasoning_type=ReasoningType.ALGEBRAIC,
                description="Solve for variable",
                explanation="Calculate the final solution"
            ),
        ]
        
        problem.steps = steps
    
    def _geometric_reasoning(self, problem: MathProblem) -> None:
        """Geometric problem solving"""
        
        steps = [
            MathStep(
                step_number=1,
                reasoning_type=ReasoningType.GEOMETRIC,
                description="Draw and analyze figure",
                explanation="Visualize the geometric configuration"
            ),
            MathStep(
                step_number=2,
                reasoning_type=ReasoningType.GEOMETRIC,
                description="Identify geometric properties",
                explanation="Recognize angles, sides, symmetries"
            ),
            MathStep(
                step_number=3,
                reasoning_type=ReasoningType.GEOMETRIC,
                description="Apply geometric theorems",
                explanation="Use relevant theorems (Pythagorean, etc.)"
            ),
            MathStep(
                step_number=4,
                reasoning_type=ReasoningType.GEOMETRIC,
                description="Calculate result",
                explanation="Compute area, distance, or other properties"
            ),
        ]
        
        problem.steps = steps
    
    def _calculus_reasoning(self, problem: MathProblem) -> None:
        """Calculus problem solving"""
        
        steps = [
            MathStep(
                step_number=1,
                reasoning_type=ReasoningType.CALCULUS,
                description="Identify operation (derivative/integral)",
                explanation="Determine if we need differentiation or integration"
            ),
            MathStep(
                step_number=2,
                reasoning_type=ReasoningType.CALCULUS,
                description="Choose appropriate rule",
                explanation="Select power rule, product rule, chain rule, etc."
            ),
            MathStep(
                step_number=3,
                reasoning_type=ReasoningType.CALCULUS,
                description="Apply differentiation/integration",
                explanation="Execute the calculus operation",
                formula="d/dx[x^n] = n*x^(n-1)"
            ),
            MathStep(
                step_number=4,
                reasoning_type=ReasoningType.CALCULUS,
                description="Simplify result",
                explanation="Simplify to final form"
            ),
        ]
        
        problem.steps = steps
    
    def _statistical_reasoning(self, problem: MathProblem) -> None:
        """Statistical problem solving"""
        
        steps = [
            MathStep(
                step_number=1,
                reasoning_type=ReasoningType.STATISTICAL,
                description="Identify distribution type",
                explanation="Recognize normal, binomial, Poisson, etc."
            ),
            MathStep(
                step_number=2,
                reasoning_type=ReasoningType.STATISTICAL,
                description="Calculate parameters",
                explanation="Find mean, variance, standard deviation"
            ),
            MathStep(
                step_number=3,
                reasoning_type=ReasoningType.STATISTICAL,
                description="Apply statistical test",
                explanation="Use t-test, chi-square, z-test, etc."
            ),
            MathStep(
                step_number=4,
                reasoning_type=ReasoningType.STATISTICAL,
                description="Interpret results",
                explanation="Determine significance and conclusions"
            ),
        ]
        
        problem.steps = steps
    
    def _logic_reasoning(self, problem: MathProblem) -> None:
        """Logical proof and reasoning"""
        
        steps = [
            MathStep(
                step_number=1,
                reasoning_type=ReasoningType.LOGIC,
                description="State assumptions",
                explanation="List given premises and axioms"
            ),
            MathStep(
                step_number=2,
                reasoning_type=ReasoningType.LOGIC,
                description="Build logical chain",
                explanation="Connect statements through logical operators"
            ),
            MathStep(
                step_number=3,
                reasoning_type=ReasoningType.LOGIC,
                description="Apply inference rules",
                explanation="Use modus ponens, modus tollens, etc."
            ),
            MathStep(
                step_number=4,
                reasoning_type=ReasoningType.LOGIC,
                description="Conclude proof",
                explanation="Derive the final conclusion"
            ),
        ]
        
        problem.steps = steps
    
    def _computational_reasoning(self, problem: MathProblem) -> None:
        """Computational/numerical problem solving"""
        
        steps = [
            MathStep(
                step_number=1,
                reasoning_type=ReasoningType.COMPUTATIONAL,
                description="Parse input",
                explanation="Understand the computational problem"
            ),
            MathStep(
                step_number=2,
                reasoning_type=ReasoningType.COMPUTATIONAL,
                description="Choose algorithm",
                explanation="Select appropriate computational method"
            ),
            MathStep(
                step_number=3,
                reasoning_type=ReasoningType.COMPUTATIONAL,
                description="Execute computation",
                explanation="Run the algorithm step by step"
            ),
            MathStep(
                step_number=4,
                reasoning_type=ReasoningType.COMPUTATIONAL,
                description="Format output",
                explanation="Present result in clear format"
            ),
        ]
        
        problem.steps = steps
    
    def verify_solution(self, problem: MathProblem, solution: str) -> Tuple[bool, float]:
        """Verify mathematical solution"""
        
        # Placeholder verification - in production would use SymPy or similar
        confidence = 0.9
        
        # Check if solution looks valid
        if solution and len(solution) > 0:
            verification_passed = True
        else:
            verification_passed = False
            confidence = 0.1
        
        problem.verification_passed = verification_passed
        return verification_passed, confidence
    
    def explain_solution(self, problem: MathProblem) -> str:
        """Generate explanation of solution"""
        
        explanation = f"<reasoning>\n"
        explanation += f"Problem: {problem.problem_statement}\n"
        explanation += f"Type: {problem.problem_type.value}\n"
        explanation += f"Difficulty: {problem.difficulty_score:.2f}\n\n"
        
        explanation += "Steps:\n"
        for step in problem.steps:
            explanation += f"\n{step.step_number}. {step.description}\n"
            explanation += f"   {step.explanation}\n"
            if step.formula:
                explanation += f"   Formula: {step.formula}\n"
        
        if problem.final_answer:
            explanation += f"\nFinal Answer: {problem.final_answer}\n"
        
        if problem.verification_passed:
            explanation += "Verification: ✓ Passed\n"
        else:
            explanation += "Verification: ✗ Failed\n"
        
        explanation += "</reasoning>\n"
        
        return explanation
    
    def solve(self, problem_statement: str) -> Tuple[MathProblem, str]:
        """Solve mathematical problem end-to-end"""
        
        # Parse problem
        problem = self.parse_problem(problem_statement)
        
        # Generate reasoning steps
        self.generate_reasoning_steps(problem)
        
        # Set final answer (placeholder)
        problem.final_answer = "Solution calculated"
        
        # Verify
        self.verify_solution(problem, problem.final_answer)
        
        # Store in history
        self.reasoning_history.append(problem)
        
        # Generate explanation
        explanation = self.explain_solution(problem)
        
        return problem, explanation


class ScienceReasoningEngine:
    """Scientific reasoning and explanation engine"""
    
    def __init__(self):
        self.math_reasoner = GLM4MathReasoner()
        self.scientific_domains = [
            'physics', 'chemistry', 'biology',
            'astronomy', 'geology', 'meteorology'
        ]
    
    def identify_domain(self, query: str) -> Optional[str]:
        """Identify scientific domain"""
        
        query_lower = query.lower()
        
        for domain in self.scientific_domains:
            if domain in query_lower:
                return domain
        
        return None
    
    def generate_scientific_explanation(self, query: str) -> str:
        """Generate scientific explanation with reasoning"""
        
        domain = self.identify_domain(query)
        
        explanation = f"<math>\n"
        explanation += f"Domain: {domain or 'General Science'}\n\n"
        explanation += f"Query: {query}\n\n"
        explanation += self._generate_domain_explanation(query, domain)
        explanation += "</math>\n"
        
        return explanation
    
    def _generate_domain_explanation(self, query: str, domain: Optional[str]) -> str:
        """Generate domain-specific explanation"""
        
        explanations = {
            'physics': "Physics involves analyzing forces, energy, motion, and interactions.\n",
            'chemistry': "Chemistry involves reactions, molecular structures, and chemical bonds.\n",
            'biology': "Biology involves living organisms, evolution, and life processes.\n",
            'astronomy': "Astronomy involves celestial objects, space, and cosmic phenomena.\n",
            'geology': "Geology involves rocks, minerals, earth structure, and plate tectonics.\n",
            'meteorology': "Meteorology involves weather, atmosphere, and climate systems.\n",
        }
        
        if domain and domain in explanations:
            return explanations[domain]
        
        return "This involves scientific principles and reasoning.\n"


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    # Test GLM-4-Math
    reasoner = GLM4MathReasoner()
    
    # Example problems
    problems = [
        "Solve for x: 2x + 5 = 13",
        "Find the derivative of x^3 + 2x^2 - 5x + 3",
        "Calculate the area of a circle with radius 5",
    ]
    
    print("=" * 80)
    print("GLM-4-MATH REASONING ENGINE")
    print("=" * 80)
    
    for problem_text in problems:
        print(f"\n\nProblem: {problem_text}")
        problem, explanation = reasoner.solve(problem_text)
        print(explanation)
    
    # Test Science Reasoning
    print("\n" + "=" * 80)
    print("SCIENCE REASONING ENGINE")
    print("=" * 80)
    
    science_engine = ScienceReasoningEngine()
    science_queries = [
        "Explain photosynthesis in plants",
        "How does gravity work in physics?",
        "What causes weather patterns in meteorology?",
    ]
    
    for query in science_queries:
        print(f"\nQuery: {query}")
        explanation = science_engine.generate_scientific_explanation(query)
        print(explanation)
