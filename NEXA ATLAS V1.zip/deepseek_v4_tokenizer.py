#!/usr/bin/env python3
"""
DeepSeek-style v4 Tokenizer
- Byte-level BPE (256K vocabulary)
- Multilingual efficiency
- Code-aware tokenization
- UTF-safe handling
- Long-context stability
- Special reasoning tokens
"""

import json
import re
from typing import Dict, List, Tuple, Optional, Set
from collections import defaultdict, Counter
import logging

logger = logging.getLogger(__name__)


class DeepSeekV4Tokenizer:
    """DeepSeek v4 style BPE tokenizer with advanced features"""
    
    # Special tokens
    PAD_TOKEN = "<pad>"
    EOS_TOKEN = "<eos>"
    BOS_TOKEN = "<bos>"
    UNK_TOKEN = "<unk>"
    
    # Reasoning tokens for GLM-5.1
    REASONING_START = "<reasoning>"
    REASONING_END = "</reasoning>"
    MATH_START = "<math>"
    MATH_END = "</math>"
    CODE_START = "<code>"
    CODE_END = "</code>"
    
    # Special control tokens
    SPECIAL_TOKENS = {
        PAD_TOKEN: 0,
        EOS_TOKEN: 1,
        BOS_TOKEN: 2,
        UNK_TOKEN: 3,
        REASONING_START: 4,
        REASONING_END: 5,
        MATH_START: 6,
        MATH_END: 7,
        CODE_START: 8,
        CODE_END: 9,
    }
    
    def __init__(self, vocab_size: int = 256000, 
                 cache_size: int = 100000,
                 multilingual: bool = True,
                 code_aware: bool = True):
        """Initialize tokenizer with DeepSeek v4 features"""
        
        self.vocab_size = vocab_size
        self.cache_size = cache_size
        self.multilingual = multilingual
        self.code_aware = code_aware
        
        # BPE vocabulary (word -> token_id)
        self.vocab: Dict[str, int] = {}
        self.decode_vocab: Dict[int, str] = {}
        
        # Initialize with special tokens
        for token, token_id in self.SPECIAL_TOKENS.items():
            self.vocab[token] = token_id
            self.decode_vocab[token_id] = token
        
        # BPE merge rules
        self.merges: List[Tuple[str, str]] = []
        self.merge_dict: Dict[Tuple[str, str], int] = {}
        
        # Encoding cache
        self.cache: Dict[str, List[int]] = {}
        self.cache_hits = 0
        self.cache_misses = 0
        
        # Language-specific patterns for multilingual support
        self.language_patterns = self._init_language_patterns()
        
        # Code patterns for code-aware tokenization
        self.code_patterns = self._init_code_patterns() if code_aware else {}
        
        logger.info(f"Initialized DeepSeek v4 Tokenizer "
                   f"(vocab_size={vocab_size}, "
                   f"multilingual={multilingual}, "
                   f"code_aware={code_aware})")
    
    def _init_language_patterns(self) -> Dict[str, re.Pattern]:
        """Initialize multilingual language patterns"""
        return {
            'chinese': re.compile(r'[\u4e00-\u9fff]+'),
            'japanese': re.compile(r'[\u3040-\u309f\u30a0-\u30ff]+'),
            'korean': re.compile(r'[\uac00-\ud7af]+'),
            'arabic': re.compile(r'[\u0600-\u06ff]+'),
            'hebrew': re.compile(r'[\u0590-\u05ff]+'),
            'cyrillic': re.compile(r'[\u0400-\u04ff]+'),
            'devanagari': re.compile(r'[\u0900-\u097f]+'),
        }
    
    def _init_code_patterns(self) -> Dict[str, re.Pattern]:
        """Initialize code-aware tokenization patterns"""
        return {
            'python_keyword': re.compile(
                r'\b(def|class|if|else|for|while|return|import|from|as|with|try|except|finally)\b'
            ),
            'operator': re.compile(r'[+\-*/%=<>!&|^~]+'),
            'delimiter': re.compile(r'[(){}\[\];:,.]'),
            'string': re.compile(r'(["\'])(?:(?=(\\?))\2.)*?\1'),
            'number': re.compile(r'\d+\.?\d*|\b0x[0-9a-fA-F]+\b'),
            'comment': re.compile(r'#.*$|/\*.*?\*/', re.MULTILINE),
        }
    
    def _is_language_text(self, text: str) -> Optional[str]:
        """Detect if text is from specific language"""
        for lang, pattern in self.language_patterns.items():
            if pattern.search(text):
                return lang
        return None
    
    def _is_code_segment(self, text: str) -> bool:
        """Detect if text appears to be code"""
        code_indicators = [
            'def ', 'class ', 'import ', 'return ', 'function ',
            '==', '=>', '==', '!=', '&&', '||', '+=', '-=',
            '{', '}', '()', '[]', ';', ':'
        ]
        
        if self.code_aware:
            return sum(1 for indicator in code_indicators if indicator in text) >= 2
        return False
    
    def _split_text_intelligently(self, text: str) -> List[str]:
        """Intelligently split text considering language and code"""
        
        # Preserve special tokens
        for token in self.SPECIAL_TOKENS.keys():
            text = text.replace(token, f" {token} ")
        
        # Code-aware splitting
        if self._is_code_segment(text):
            return self._split_code_text(text)
        
        # Language-specific splitting
        lang = self._is_language_text(text)
        if lang:
            return self._split_language_text(text, lang)
        
        # Default: split on whitespace and punctuation
        pattern = r'\w+|[^\w\s]'
        return re.findall(pattern, text)
    
    def _split_code_text(self, text: str) -> List[str]:
        """Split code text with awareness of syntax"""
        tokens = []
        
        # Match code elements in order of specificity
        for pattern_type, pattern in self.code_patterns.items():
            text = pattern.sub(lambda m: f" {m.group()} ", text)
        
        # Split on whitespace
        tokens = text.split()
        return [t for t in tokens if t]
    
    def _split_language_text(self, text: str, language: str) -> List[str]:
        """Split multilingual text appropriately"""
        
        if language in ['chinese', 'japanese']:
            # Character-level for CJK
            return list(text)
        elif language in ['korean', 'thai', 'khmer', 'lao']:
            # Syllable-level
            return self._split_syllables(text)
        else:
            # Standard word-level
            return text.split()
    
    def _split_syllables(self, text: str) -> List[str]:
        """Split CJK and similar scripts into syllables"""
        # Simplified: treat each character as unit
        return list(text)
    
    def _build_byte_level_vocabulary(self) -> None:
        """Build initial byte-level vocabulary (256 byte tokens)"""
        
        next_token_id = len(self.SPECIAL_TOKENS)
        
        # Add all 256 byte values
        for byte_val in range(256):
            byte_token = f"<byte_{byte_val:02x}>"
            self.vocab[byte_token] = next_token_id
            self.decode_vocab[next_token_id] = byte_token
            next_token_id += 1
    
    def _bytes_to_tokens(self, text: str) -> List[str]:
        """Convert text to byte-level tokens"""
        byte_tokens = []
        
        for byte_val in text.encode('utf-8'):
            byte_token = f"<byte_{byte_val:02x}>"
            byte_tokens.append(byte_token)
        
        return byte_tokens
    
    def _text_to_subwords(self, text: str) -> List[str]:
        """Convert text to initial subword tokens"""
        
        # Split intelligently
        words = self._split_text_intelligently(text)
        
        subwords = []
        for word in words:
            # Add word boundary marker
            word = word + "</w>"
            
            # Convert to bytes then to tokens
            try:
                byte_tokens = self._bytes_to_tokens(word)
                subwords.extend(byte_tokens)
            except Exception as e:
                logger.warning(f"Error encoding word '{word}': {e}")
                subwords.append(self.UNK_TOKEN)
        
        return subwords
    
    def _get_stats(self, tokens: List[str]) -> Counter:
        """Get frequency of adjacent token pairs"""
        pairs = Counter()
        
        for i in range(len(tokens) - 1):
            pairs[tokens[i], tokens[i + 1]] += 1
        
        return pairs
    
    def _merge_pair(self, tokens: List[str], 
                   pair: Tuple[str, str]) -> List[str]:
        """Merge a specific pair in token list"""
        
        new_tokens = []
        i = 0
        
        while i < len(tokens):
            if i < len(tokens) - 1 and (tokens[i], tokens[i + 1]) == pair:
                new_tokens.append(pair[0] + pair[1])
                i += 2
            else:
                new_tokens.append(tokens[i])
                i += 1
        
        return new_tokens
    
    def _train_bpe(self, texts: List[str], num_merges: int = 20000) -> None:
        """Train BPE merges from texts"""
        
        logger.info(f"Training BPE with {num_merges} merges from {len(texts)} texts")
        
        # Initialize vocabulary with subwords
        all_tokens = []
        for text in texts:
            tokens = self._text_to_subwords(text)
            all_tokens.extend(tokens)
        
        # Train BPE
        for merge_idx in range(num_merges):
            if merge_idx % 1000 == 0:
                logger.info(f"BPE merge {merge_idx}/{num_merges}")
            
            # Get most common pair
            pairs = self._get_stats(all_tokens)
            if not pairs:
                break
            
            best_pair = pairs.most_common(1)[0][0]
            
            # Merge pair
            all_tokens = self._merge_pair(all_tokens, best_pair)
            self.merges.append(best_pair)
            
            # Add to merge dict
            merge_id = len(self.SPECIAL_TOKENS) + 256 + len(self.merges)
            self.merge_dict[best_pair] = merge_id
        
        logger.info(f"Completed BPE training with {len(self.merges)} merges")
    
    def encode(self, text: str, max_length: Optional[int] = None) -> List[int]:
        """Encode text to token IDs with caching"""
        
        # Check cache
        if text in self.cache:
            self.cache_hits += 1
            token_ids = self.cache[text]
        else:
            self.cache_misses += 1
            
            # Convert to subwords
            tokens = self._text_to_subwords(text)
            
            # Apply BPE merges
            for pair in self.merges:
                tokens = self._merge_pair(tokens, pair)
            
            # Convert to token IDs
            token_ids = []
            for token in tokens:
                if token in self.vocab:
                    token_ids.append(self.vocab[token])
                else:
                    # Register new token
                    token_id = len(self.vocab)
                    self.vocab[token] = token_id
                    self.decode_vocab[token_id] = token
                    token_ids.append(token_id)
            
            # Add to cache if space available
            if len(self.cache) < self.cache_size:
                self.cache[text] = token_ids
        
        # Apply max length
        if max_length:
            token_ids = token_ids[:max_length]
        
        return token_ids
    
    def decode(self, token_ids: List[int]) -> str:
        """Decode token IDs to text"""
        
        tokens = []
        for token_id in token_ids:
            if token_id in self.decode_vocab:
                tokens.append(self.decode_vocab[token_id])
            else:
                tokens.append(self.UNK_TOKEN)
        
        # Merge tokens
        text = ' '.join(tokens)
        
        # Clean up byte tokens
        text = re.sub(r'<byte_[0-9a-f]{2}>', '', text)
        
        # Remove word boundaries
        text = text.replace('</w>', '')
        
        return text.strip()
    
    def batch_encode(self, texts: List[str], 
                    max_length: Optional[int] = None,
                    padding: bool = True) -> Tuple[List[List[int]], List[int]]:
        """Batch encode with optional padding"""
        
        encoded = [self.encode(text, max_length) for text in texts]
        
        if padding:
            # Find max length
            max_len = max(len(seq) for seq in encoded) if encoded else 0
            if max_length and max_length < max_len:
                max_len = max_length
            
            # Pad sequences
            padded = []
            lengths = []
            
            for seq in encoded:
                length = len(seq)
                seq = seq[:max_len]
                seq.extend([self.SPECIAL_TOKENS[self.PAD_TOKEN]] * (max_len - len(seq)))
                padded.append(seq)
                lengths.append(length)
            
            return padded, lengths
        
        return encoded, [len(seq) for seq in encoded]
    
    def get_vocab_size(self) -> int:
        """Get current vocabulary size"""
        return len(self.vocab)
    
    def get_stats(self) -> Dict:
        """Get tokenizer statistics"""
        return {
            'vocab_size': len(self.vocab),
            'num_merges': len(self.merges),
            'cache_size': len(self.cache),
            'cache_hits': self.cache_hits,
            'cache_misses': self.cache_misses,
            'cache_hit_rate': self.cache_hits / (self.cache_hits + self.cache_misses) 
                            if (self.cache_hits + self.cache_misses) > 0 else 0,
            'special_tokens': len(self.SPECIAL_TOKENS),
            'reasoning_tokens': 6,  # START, END pairs
        }
    
    def save(self, filepath: str) -> None:
        """Save tokenizer to file"""
        
        data = {
            'vocab': self.vocab,
            'merges': self.merges,
            'special_tokens': self.SPECIAL_TOKENS,
            'vocab_size': self.vocab_size,
            'multilingual': self.multilingual,
            'code_aware': self.code_aware,
        }
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        logger.info(f"Tokenizer saved to {filepath}")
    
    def load(self, filepath: str) -> None:
        """Load tokenizer from file"""
        
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        self.vocab = data['vocab']
        self.merges = data['merges']
        
        # Rebuild decode vocab
        self.decode_vocab = {v: k for k, v in self.vocab.items()}
        
        logger.info(f"Tokenizer loaded from {filepath} "
                   f"(vocab_size={len(self.vocab)})")


# Example usage and testing
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    # Create tokenizer
    tokenizer = DeepSeekV4Tokenizer(
        vocab_size=256000,
        multilingual=True,
        code_aware=True
    )
    
    # Example texts
    texts = [
        "Machine learning is a subset of artificial intelligence.",
        "def hello_world():\n    print('Hello, World!')",
        "机器学习是人工智能的一个子集。",
        "The quick brown fox jumps over the lazy dog.",
    ]
    
    # Train on example texts
    logger.info("Training tokenizer on example texts...")
    tokenizer._train_bpe(texts, num_merges=1000)
    
    # Test encoding
    test_text = "Hello, world! This is a test of the DeepSeek v4 tokenizer."
    token_ids = tokenizer.encode(test_text)
    decoded = tokenizer.decode(token_ids)
    
    print(f"\nOriginal: {test_text}")
    print(f"Encoded: {token_ids[:20]}... (total: {len(token_ids)})")
    print(f"Decoded: {decoded}")
    
    # Print stats
    stats = tokenizer.get_stats()
    print(f"\nTokenizer Stats:")
    for key, value in stats.items():
        print(f"  {key}: {value}")
